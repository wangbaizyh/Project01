create
    definer = root@localhost procedure test_randstr_insert(IN insertCount int)
BEGIN
DECLARE i INT DEFAULT 1;
DECLARE str VARCHAR(26) DEFAULT 'abcdefghijklmnopqrstuvwxyz';
DECLARE startIndex INT DEFAULT 1;
DECLARE len INT DEFAULT 1;
WHILE i<=insertCount DO
SET startIndex=FLOOR(RAND()*26+1);
SET len=FLOOR(RAND()*(20-startIndex+1)+1);
INSERT INTO stringcontent(content) VALUES(SUBSTR(str,stratIndex,len));

SET i=i+1;
END WHILE;

END;

